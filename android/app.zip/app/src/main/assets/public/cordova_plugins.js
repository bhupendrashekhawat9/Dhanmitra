
  cordova.define('cordova/plugin_list', function(require, exports, module) {
    module.exports = [
      {
          "id": "cordova-plugin-sms-retriever.SMSRetriever",
          "file": "plugins/cordova-plugin-sms-retriever/www/SMSRetriever.js",
          "pluginId": "cordova-plugin-sms-retriever",
        "clobbers": [
          "cordova.plugins.SMSRetriever"
        ]
        },
      {
          "id": "cordova-plugin-sms.SMS",
          "file": "plugins/cordova-plugin-sms/www/SMS.js",
          "pluginId": "cordova-plugin-sms",
        "clobbers": [
          "window.SMS"
        ]
        }
    ];
    module.exports.metadata =
    // TOP OF METADATA
    {
      "cordova-plugin-sms": "1.0.5",
      "cordova-plugin-sms-retriever": "4.0.4"
    };
    // BOTTOM OF METADATA
    });
    